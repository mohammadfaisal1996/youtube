import time
import os
import random
from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import subprocess

# Infinite loop to retry every 20 minutes
while True:
    try:
        # Get the current directory
        current_dir = os.path.dirname(os.path.realpath(__file__))

        # Delete all .mp4 files in the current directory before downloading a new video
        for file in os.listdir(current_dir):
            if file.endswith('.mp4'):
                os.remove(os.path.join(current_dir, file))

        # Generate a random keyword or number to append to the search query
        random_keyword = str(random.randint(1000, 9999))
        search_query = f'10 seconds about food {random_keyword}'

        # Step 1: Run the Python script to download a random video
        download_command = f'python3 {current_dir}/test.py "{search_query}"'
        subprocess.run(download_command, shell=True, check=True)

        # Step 2: Find the downloaded video in the current directory
        video_file = None
        for file in os.listdir(current_dir):
            if file.endswith('.mp4'):
                video_file = os.path.join(current_dir, file)
                break

        if video_file is None:
            raise Exception("No video file was downloaded.")

        # Step 3: Re-encode the video to ensure compatibility
        encoded_file = os.path.join(current_dir, "downloaded_video_encoded.mp4")
        ffmpeg_command = f'ffmpeg -i "{video_file}" -c:v libx264 -c:a aac -strict -2 -movflags +faststart "{encoded_file}"'
        subprocess.run(ffmpeg_command, shell=True, check=True)

        # Step 4: Rename the encoded video file to a simpler format
        simplified_path = os.path.join(current_dir, "downloaded_video.mp4")
        os.rename(encoded_file, simplified_path)

        # Verify the renamed file exists
        if not os.path.isfile(simplified_path):
            raise Exception("Renamed video file not found.")

        # Step 5: Delete everything in the Download directory on the emulator
        delete_command = 'adb -s emulator-5554 shell rm -rf /sdcard/Download/*'
        subprocess.run(delete_command, shell=True, check=True)

        # Step 6: Push the renamed video to the emulator's Download directory
        push_command = f'adb -s emulator-5554 push "{simplified_path}" /sdcard/Download/'
        subprocess.run(push_command, shell=True, check=True)

        # Verify the file was pushed correctly
        check_command = 'adb -s emulator-5554 shell ls /sdcard/Download/'
        result = subprocess.run(check_command, shell=True, capture_output=True, text=True)
        if "downloaded_video.mp4" not in result.stdout:
            raise Exception("Video file was not successfully pushed to the emulator's Download directory.")

        # Step 7: Reboot the emulator
        reboot_command = 'adb -s emulator-5554 reboot'
        subprocess.run(reboot_command, shell=True, check=True)

        # Step 8: Wait for the emulator to boot completely (20 seconds)
        time.sleep(20)

        # Set up desired capabilities using UiAutomator2Options
        options = UiAutomator2Options()
        options.platform_name = "Android"
        options.device_name = "emulator-5554"
        options.app_package = "com.google.android.youtube"
        options.app_activity = "com.google.android.youtube.HomeActivity"
        options.automation_name = "UiAutomator2"
        options.no_reset = True  # Prevents app from being reset between sessions

        # Initialize the Appium driver with the options
        driver = webdriver.Remote('http://localhost:4723/wd/hub', options=options)

        # Set up a wait with a timeout of 10 seconds
        wait = WebDriverWait(driver, 10)

        try:
            # Wait until the "Create" button is visible and then click it
            el1 = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "Create")))
            el1.click()

            # Wait until the specific element in the RecyclerView is visible and then click it
            el4 = wait.until(EC.presence_of_element_located((By.ID, "com.google.android.youtube:id/thumb_image_view")))
            el4.click()

            # Wait for 5 seconds
            time.sleep(5)
            
            # Tap on coordinates using adb command
            tap_command = 'adb -s emulator-5554 shell input tap 544 857'
            subprocess.run(tap_command, shell=True, check=True)

            # Wait until the "Next" button or text appears and then click it
            el5 = wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(@text, 'Next') or contains(@content-desc, 'Next')]")))
            el5.click()

            try:
                # Attempt the first case: click on post/upload buttons
                el6 = wait.until(EC.presence_of_element_located((By.ID, "com.google.android.youtube:id/shorts_post_bottom_button")))
                el6.click()

                el7 = wait.until(EC.presence_of_element_located((By.ID, "com.google.android.youtube:id/upload_bottom_button")))
                el7.click()
                time.sleep(10)

            except TimeoutException:
                # If the first case fails, try the second case
                el8 = wait.until(EC.presence_of_element_located((By.ID, "com.google.android.youtube:id/upload_menu_button")))
                el8.click()

                # Wait for 5 seconds before proceeding to click the "Next" button
                time.sleep(5)

                xpath_element = wait.until(EC.presence_of_element_located((By.XPATH, "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]")))
                xpath_element.click()

                # Wait for the "Upload video" button and click it
                upload_video_button = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "Upload video")))
                upload_video_button.click()

                # Wait for the upload to complete
                time.sleep(5)

        finally:
            # Quit the driver session
            driver.quit()

    except Exception as e:
        print(f"An error occurred: {e}")
    
    # Wait for 20 minutes before retrying
    time.sleep(1200)  # 1200 seconds = 20 minutes

