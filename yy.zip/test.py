import random
import os
import yt_dlp
import sys
from youtubesearchpython import VideosSearch

searchCategory = sys.argv[1]
MAX_DURATION = 90  # Maximum duration in seconds
MAX_SIZE_MB = 15   # Maximum file size in MB
TARGET_RESOLUTION = '720p'  # Resolution target
TARGET_BITRATE = 500 * 1024  # Target bitrate

def get_random_video_url(category_query):
    videos_search = VideosSearch(category_query, limit=50)
    search_results = videos_search.result()

    if not search_results or 'result' not in search_results:
        return None

    video_links = [result['link'] for result in search_results['result']]

    if not video_links:
        return None

    # Load previously downloaded video URLs
    downloaded_videos = set()
    if os.path.exists('downloaded_videos.txt'):
        with open('downloaded_videos.txt', 'r') as file:
            downloaded_videos = set(line.strip() for line in file.readlines())

    # Filter out already downloaded videos
    unique_video_links = [link for link in video_links if link not in downloaded_videos]

    if not unique_video_links:
        print("No new unique videos found.")
        return None

    # Shuffle the list to add randomness
    random.shuffle(unique_video_links)

    return unique_video_links

def download_video(video_url, download_path='.', resolution=TARGET_RESOLUTION, max_size_mb=MAX_SIZE_MB):
    ydl_opts = {
        'outtmpl': f'{download_path}/%(title)s.%(ext)s',
        'noplaylist': True,
        'quiet': True,
        'format': f'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]',
        'merge_output_format': 'mp4'
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(video_url, download=False)

            # Check video duration
            duration = info_dict.get('duration', 0)
            if duration > MAX_DURATION:
                print(f"Skipping {info_dict['title']}: Duration {duration // 60}m {duration % 60}s exceeds 90 seconds.")
                return False

            # Check file size and bitrate
            if 'filesize' in info_dict:
                file_size_mb = info_dict['filesize'] / (1024 * 1024)
            elif 'filesize_approx' in info_dict:
                file_size_mb = info_dict['filesize_approx'] / (1024 * 1024)
            else:
                file_size_mb = float('inf')

            bitrate = info_dict.get('bit_rate', 0)
            if bitrate > TARGET_BITRATE:
                print(f"Skipping {info_dict['title']}: Bitrate {bitrate // 1024} kbps exceeds {TARGET_BITRATE // 1024} kbps.")
                return False

            if file_size_mb <= max_size_mb:
                print(f"Downloading: {info_dict['title']} (Size: {file_size_mb:.2f} MB, Duration: {duration // 60}m {duration % 60}s, Bitrate: {bitrate // 1024} kbps)")
                ydl.download([video_url])

                # Log the downloaded video URL
                with open('downloaded_videos.txt', 'a') as file:
                    file.write(f"{video_url}\n")

                print(f"Download completed: {info_dict['title']}")
                return True
            else:
                print(f"Skipping {info_dict['title']}: File size {file_size_mb:.2f} MB exceeds {max_size_mb} MB")
                return False
    except Exception as e:
        print(f'Error downloading video: {e}')
        return False

if __name__ == "__main__":
    CATEGORY_QUERY = sys.argv[1]

    video_urls = get_random_video_url(CATEGORY_QUERY)

    if video_urls:
        for video_url in video_urls:
            print(f'Trying to download: {video_url}')
            if download_video(video_url):
                break
    else:
        print("No videos found.")

